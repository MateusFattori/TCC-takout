// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyCdqiWhljCiacIirLqEtz9YSq-7e2SwS6g',
    authDomain: 'takout-16f62.firebaseapp.com',
    projectId: 'takout-16f62',
    storageBucket: 'takout-16f62.appspot.com',
    messagingSenderId: '216685805443',
    appId: '1:216685805443:web:46a0e9baa08632a15ec0b6',
    measurementId: 'G-4NGJ21E657'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
