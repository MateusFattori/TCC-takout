console.log('meu pau ta duandu');
