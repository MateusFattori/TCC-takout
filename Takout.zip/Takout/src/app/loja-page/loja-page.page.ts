import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loja-page',
  templateUrl: './loja-page.page.html',
  styleUrls: ['./loja-page.page.scss'],
})
export class LojaPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
