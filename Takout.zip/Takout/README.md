# TCC
Este é o projeto de TCC do grupo Takout - 3EMIA 2022


## Equipe Takout
- Guilherme Loschiavo
- João Victor Rosinhole
- Pedro Henrique Frigo
- Gabriel Festa
- Gabriel Kenta Tarumoto
- Vitor Shimizu
- Vinícius Olivetti
- Mateus Fattori
