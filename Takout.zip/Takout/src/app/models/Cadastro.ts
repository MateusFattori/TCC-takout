export class Cadastro {
  id: string;
  nome: string;
  senha: string;
}

